<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_name'])) {
    header("Location: ../auth/login.php"); // Redirect if not logged in
    exit();
}
?>

<!-- HTML for header -->
<div class="header">
    <div class="logo">
        <a href="index.php">📚 Saif Book Store</a>
    </div>
    <div class="user-info">
        <p>👋 Welcome, <strong><?= htmlspecialchars($_SESSION['user_name']); ?></strong></p>
        <a href="../auth/logout.php" class="btn-logout">🚪 Logout</a>
    </div>
</div>

<style>
    .header {
        background-color: #333;
        padding: 10px 20px;
        color: white;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    .logo a {
        color: #ff9800;
        text-decoration: none;
        font-size: 18px;
        font-weight: bold;
    }
    .user-info p {
        margin: 0;
    }
    .btn-logout {
        background-color: #ff4d4d;
        padding: 5px 10px;
        border-radius: 5px;
        color: white;
        text-decoration: none;
        margin-left: 10px;
    }
    .btn-logout:hover {
        background-color: #ff3333;
    }
</style>
