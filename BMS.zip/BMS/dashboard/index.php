
<?php
session_start();
include '../includes/config.php';


// Initialize search variables
$search_name = isset($_GET['search_name']) ? mysqli_real_escape_string($conn, $_GET['search_name']) : '';
$min_price = isset($_GET['min_price']) ? intval($_GET['min_price']) : 0;
$max_price = isset($_GET['max_price']) ? intval($_GET['max_price']) : 10000;

// Build search query
$query = "SELECT * FROM books1 WHERE 1";

// Add search by name
if (!empty($search_name)) {
    $query .= " AND book_name LIKE '%$search_name%'";
}

// Add price range filter
if ($min_price > 0 && $max_price > 0) {
    $query .= " AND price BETWEEN $min_price AND $max_price";
}

// Order by latest books
$query .= " ORDER BY created_at DESC";

$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="../css/styles.css">
    <title>Book Dashboard</title>
    <style>
        .container {
            width: 80%;
            margin: 0 auto;
        }
        .book-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
        }
        .book-card {
            border: 1px solid #ccc;
            border-radius: 8px;
            padding: 15px;
            background-color: #f9f9f9;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            text-align: center;
            transition: transform 0.3s ease-in-out;
            cursor: pointer;
        }
        .book-card:hover {
            transform: scale(1.03);
        }
        .main-book-image {
            width: 150px;
            height: 220px;
            border-radius: 8px;
            object-fit: cover;
            border: 2px solid #ddd;
        }
        .book-name {
            margin-top: 10px;
            font-weight: bold;
            color: #333;
        }
        .author-name {
            color: #666;
            font-size: 14px;
        }
        .search-container {
            margin-bottom: 20px;
            padding: 10px;
            background-color: #f1f1f1;
            border-radius: 8px;
        }
        .search-container input, .search-container button {
            padding: 10px;
            margin-right: 5px;
        }
        .btn-search {
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 5px;
        }
        .btn-search:hover {
            background-color: #45a049;
        }



           /* Header Styles */
           .header-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px 50px;
            background-color: #4CAF50;
            color: white;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }
        .logo {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid white;
        }
        .store-title {
            font-size: 28px;
            font-weight: bold;
            margin-left: 15px;
        }
        .header-title {
            display: flex;
            align-items: center;
        }
        h2 {
            text-align: center;
            margin-top: 20px;
            color: #333;
        }
    </style>
</head>
<body>
   
         <!-- Header Section -->
    <div class="header-container">
        <div class="header-title">
            <img src="logobook-removebg-preview.png" alt="Saif Book Store Logo" class="logo">
            <span class="store-title">Saif Book Store 📚</span>
        </div>
    </div>

        <div class="book-grid">
            <?php if (mysqli_num_rows($result) > 0) : ?>
                <?php while ($book = mysqli_fetch_assoc($result)) : ?>
                    <div class="book-card" onclick="goToDetails(<?= $book['id'] ?>)">
                        <?php $images = json_decode($book['images'], true); ?>
                        <?php if (!empty($images)) : ?>
                            <img src="../uploads/<?= htmlspecialchars($images[0]) ?>" class="main-book-image" alt="<?= htmlspecialchars($book['book_name']) ?>">
                        <?php else : ?>
                            <p>No image available</p>
                        <?php endif; ?>

                        <p class="book-name"><?= htmlspecialchars($book['book_name']) ?></p>
                        <p class="author-name">by <?= htmlspecialchars($book['author']) ?></p>
                        <p><strong>Price:</strong> ₹<?= htmlspecialchars($book['price']) ?></p>
                    </div>
                <?php endwhile; ?>
            <?php else : ?>
                <p>No books found. 📚</p>
            <?php endif; ?>
        </div>
    </div>

    <script>
        // Redirect to details page
        function goToDetails(bookId) {
            window.location.href = 'details.php?id=' + bookId;
        }
    </script>
</body>
</html>
