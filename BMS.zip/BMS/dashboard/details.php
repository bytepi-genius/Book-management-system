<?php
session_start();
include '../includes/config.php';

// Check if book ID is provided
if (isset($_GET['id'])) {
    $bookId = intval($_GET['id']);

    // Fetch book details by ID
    $query = "SELECT * FROM books1 WHERE id = $bookId";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) == 1) {
        $book = mysqli_fetch_assoc($result);
    } else {
        echo "❌ Book not found!";
        exit;
    }
} else {
    echo "❌ Invalid request!";
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="../css/styles.css">
    <title><?= htmlspecialchars($book['book_name']) ?> - Details</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 45%;
            margin: 10px auto;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 8px;
            background-color: #fff;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }
        .book-details {
            text-align: center;
        }
        .main-book-image {
            width: 250px;
            height: 350px;
            border-radius: 8px;
            object-fit: cover;
            border: 2px solid #ddd;
        }
        .book-info {
            margin-top: 20px;
            text-align: left;
        }
        .book-title {
            font-size: 28px;
            font-weight: bold;
            margin-top: 10px;
        }
        .book-author, .book-price {
            margin-top: 10px;
            font-size: 18px;
            color: #333;
        }
        .description {
            margin-top: 15px;
            font-size: 16px;
            color: #555;
        }
        #fullDescription {
            display: none;
        }
        .btn-toggle {
            color: #007BFF;
            cursor: pointer;
            font-size: 14px;
        }
        .btn-action {
            margin-top: 20px;
            padding: 10px 15px;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .btn-like {
            background-color: #ff4d4d;
        }
        .btn-buy {
            background-color: #4CAF50;
        }
        .btn-cart {
            background-color: #ff9800;
        }
        .btn-back {
            margin-top: 20px;
            display: inline-block;
            padding: 10px 15px;
            background-color: #333;
            color: white;
            border-radius: 5px;
            text-decoration: none;
        }
        .btn-back:hover {
            background-color: #555;
        }

        .main-book-image {
    width: 150px;
    height: 200px;
    border-radius: 8px;
    object-fit: cover;
    border: 2px solid #ddd;
    margin-bottom: 15px;
    transition: transform 0.3s;
}
.main-book-image:hover {
    transform: scale(1.05);
}

.thumbnail-container {
    display: flex;
    justify-content: center;
    gap: 10px;
    margin-top: 10px;
}

.thumbnail {
    width: 30px;
    height: 50px;
    border-radius: 5px;
    border: 1px solid #ccc;
    cursor: pointer;
    object-fit: cover;
    transition: transform 0.2s, border 0.2s;
}
.thumbnail:hover {
    transform: scale(1.1);
    border: 2px solid #007BFF;
}



           /* Header Styles */
           .header-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px 50px;
            background-color: #4CAF50;
            color: white;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }
        .logo {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid white;
        }
        .store-title {
            font-size: 28px;
            font-weight: bold;
            margin-left: 15px;
        }
        .header-title {
            display: flex;
            align-items: center;
        }
        h2 {
            text-align: center;
            margin-top: 20px;
            color: #333;
        }
    </style>
</head>
<body>



         <!-- Header Section -->
         <div class="header-container">
        <div class="header-title">
            <img src="logobook-removebg-preview.png" alt="Saif Book Store Logo" class="logo">
            <span class="store-title">Saif Book Store 📚</span>
        </div>
    </div>




<div class="container">
    <div class="book-details">
        <?php $images = json_decode($book['images'], true); ?>

        <!-- Main Image Display -->
        <?php if (!empty($images)) : ?>
            <img id="mainImage" src="../uploads/<?= htmlspecialchars($images[0]) ?>" 
                class="main-book-image" 
                alt="<?= htmlspecialchars($book['book_name']) ?>">
        <?php else : ?>
            <p>No image available</p>
        <?php endif; ?>

        <!-- Thumbnail Images -->
        <div class="thumbnail-container">
            <?php if (!empty($images)) : ?>
                <?php foreach ($images as $index => $image) : ?>
                    <img src="../uploads/<?= htmlspecialchars($image) ?>" 
                        class="thumbnail" 
                        onclick="changeMainImage('../uploads/<?= htmlspecialchars($image) ?>')"
                        alt="Thumbnail <?= $index + 1 ?>">
                <?php endforeach; ?>
            <?php endif; ?>
        </div>

        <!-- Book Information -->
        <div class="book-info">
            <p class="book-title"><?= htmlspecialchars($book['book_name']) ?></p>
            <p class="book-author"><strong>Author:</strong> <?= htmlspecialchars($book['author']) ?></p>
            
            <!-- Description with Read More/Read Less -->
            <p class="description">
                <span id="shortDescription"><?= htmlspecialchars(substr($book['description'], 0, 100)) ?>...</span>
                <span id="fullDescription" style="display: none;"><?= htmlspecialchars($book['description']) ?></span>
                <span class="btn-toggle" onclick="toggleDescription()">Read More</span>
            </p>

            <p class="book-price"><strong>Price:</strong> ₹<?= htmlspecialchars($book['price']) ?></p>

            <!-- Like, Buy, and Cart Buttons -->
            <button class="btn-action btn-like" onclick="likeBook(<?= $book['id'] ?>)">
                ❤️ Like (<span id="likeCount"><?= $book['likes'] ?></span>)
            </button>
            <button class="btn-action btn-buy" onclick="buyBook(<?= $book['id'] ?>)">🛒 Buy Now</button>
            <button class="btn-action btn-cart" onclick="addToCart(<?= $book['id'] ?>)">🛍️ Add to Cart</button>

            <!-- Back Button -->
            <a href="index.php" class="btn-back">⬅️ Back to Collection</a>
        </div>
    </div>
</div>


    <script>
        // Toggle Description
        function toggleDescription() {
            var shortDesc = document.getElementById('shortDescription');
            var fullDesc = document.getElementById('fullDescription');
            var toggleBtn = document.querySelector('.btn-toggle');

            if (fullDesc.style.display === 'none' || fullDesc.style.display === '') {
                fullDesc.style.display = 'inline';
                shortDesc.style.display = 'none';
                toggleBtn.innerText = 'Read Less';
            } else {
                fullDesc.style.display = 'none';
                shortDesc.style.display = 'inline';
                toggleBtn.innerText = 'Read More';
            }
        }

        // Like Button Action
        function likeBook(bookId) {
            var likeCount = document.getElementById('likeCount');
            var newCount = parseInt(likeCount.innerText) + 1;
            likeCount.innerText = newCount;
            alert('❤️ You liked this book!');
        }

        // Buy Now Action
        function buyBook(bookId) {
            alert('🛒 You bought book with ID: ' + bookId);
        }

        // Add to Cart Action
        function addToCart(bookId) {
            alert('🛍️ Book added to cart with ID: ' + bookId);
        }




        // Change Main Image on Thumbnail Click
function changeMainImage(imageSrc) {
    document.getElementById('mainImage').src = imageSrc;
}

// Toggle Description Read More / Less
function toggleDescription() {
    var shortDesc = document.getElementById('shortDescription');
    var fullDesc = document.getElementById('fullDescription');
    var toggleBtn = document.querySelector('.btn-toggle');

    if (fullDesc.style.display === 'none' || fullDesc.style.display === '') {
        fullDesc.style.display = 'inline';
        shortDesc.style.display = 'none';
        toggleBtn.innerText = 'Read Less';
    } else {
        fullDesc.style.display = 'none';
        shortDesc.style.display = 'inline';
        toggleBtn.innerText = 'Read More';
    }
}

// Like Button Action
function likeBook(bookId) {
    var likeCount = document.getElementById('likeCount');
    var newCount = parseInt(likeCount.innerText) + 1;
    likeCount.innerText = newCount;
    alert('❤️ You liked this book!');
}

// Buy Now Action
function buyBook(bookId) {
    alert('🛒 You bought book with ID: ' + bookId);
}

// Add to Cart Action
function addToCart(bookId) {
    alert('🛍️ Book added to cart with ID: ' + bookId);
}

    </script>
</body>
</html>
