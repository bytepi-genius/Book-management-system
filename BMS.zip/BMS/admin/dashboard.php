<?php
session_start();
include '../includes/config.php';

// Fetch total books
$totalBooks = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM books1"))['count'];

// Fetch total users
$totalUsers = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM users"))['count'];

// Fetch total orders
$totalOrders = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM orders"))['count'];

// Fetch total sales
$totalSales = mysqli_fetch_assoc(mysqli_query($conn, "SELECT SUM(price) as total FROM orders"))['total'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="css/admin.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>

<div class="admin-container">
    <aside class="sidebar">
        <h2>📊 Admin Panel</h2>
        <ul>
            <li><a href="dashboard.php">🏠 Dashboard</a></li>
            <li><a href="books.php">📚 Manage Books</a></li>
            <li><a href="orders.php">🛒 Orders</a></li>
            <li><a href="add-book.php">🛒 add book</a></li>

            <li><a href="users.php">👥 Users</a></li>
            <li><a href="settings.php">⚙️ Settings</a></li>
            <li><a href="../logout.php">🚪 Logout</a></li>
        </ul>
    </aside>

    <main class="content">
        <h1>📊 Dashboard</h1>

        <div class="stats">
            <div class="stat-card">📚 Total Books: <strong><?= $totalBooks ?></strong></div>
            <div class="stat-card">👥 Total Users: <strong><?= $totalUsers ?></strong></div>
            <div class="stat-card">🛒 Total Orders: <strong>500</strong></div>
            <div class="stat-card">💰 Total Sales: <strong>₹100000</strong></div>
        </div>

        <h2>📈 Sales Overview</h2>
        <canvas id="salesChart"></canvas>
    </main>
</div>

<script>
    // Dummy sales data for graph (replace with actual data from PHP)
    var salesData = {
        labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun"],
        datasets: [{
            label: "Monthly Sales",
            data: [1200, 2500, 1800, 3200, 2200, 4100], 
            backgroundColor: "rgba(54, 162, 235, 0.5)"
        }]
    };

    var ctx = document.getElementById("salesChart").getContext("2d");
    new Chart(ctx, {
        type: "bar",
        data: salesData,
    });
</script>

</body>
</html>
