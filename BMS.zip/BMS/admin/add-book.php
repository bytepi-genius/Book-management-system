<?php

include '../includes/config.php';
include '../includes/functions.php';

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $book_name   = sanitize($_POST['book_name']);
    $author      = sanitize($_POST['author']);
    $description = sanitize($_POST['description']);
    $price       = sanitize($_POST['price']);
    $like_count  = 0; // Default like count

    // Check if file count exceeds 3
    if (count($_FILES['book_images']['name']) > 3) {
        die('❌ Error: You can only upload a maximum of 3 images!');
    }

    // Upload book images
    $image_paths = [];
    $upload_dir = '../uploads/';

    for ($i = 0; $i < count($_FILES['book_images']['name']); $i++) {
        // Skip empty file inputs (if any)
        if ($_FILES['book_images']['error'][$i] == UPLOAD_ERR_NO_FILE) {
            continue;
        }

        $file_name = basename($_FILES['book_images']['name'][$i]);
        $target_file = $upload_dir . $file_name;

        // Move uploaded file to target folder
        if (move_uploaded_file($_FILES['book_images']['tmp_name'][$i], $target_file)) {
            $image_paths[] = $file_name;
        }
    }

    // Convert image paths to JSON format
    $images_json = json_encode($image_paths);

    // Insert data into database
    $query = "INSERT INTO books1 (book_name, author, description, price, images, likes) 
              VALUES ('$book_name', '$author', '$description', '$price', '$images_json', '$like_count')";

    if (mysqli_query($conn, $query)) {
        header('Location: index.php?success=Book Added Successfully!');
        exit();
    } else {
        echo '❌ Error: ' . mysqli_error($conn);
    }
}
?>



<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="../css/styles.css">
    <title>Add New Book</title>
</head>
<body>
    <div class="form-container">
        <h2>Add New Book</h2>
        <form method="POST" enctype="multipart/form-data" onsubmit="return validateImages()">
    <input type="text" name="book_name" placeholder="Book Name" required>
    <input type="text" name="author" placeholder="Author" required>
    <textarea name="description" placeholder="Description" required></textarea>
    <input type="number" name="price" placeholder="Price" required>
    <label for="book_images">Upload Images (3 max)</label>
    <input type="file" id="book_images" name="book_images[]" multiple accept="image/*" required>
    <button type="submit">Add Book</button>
</form>

<script>
    function validateImages() {
        var fileInput = document.getElementById('book_images');
        var files = fileInput.files;

        // Check if more than 3 files are selected
        if (files.length > 3) {
            alert('You can upload a maximum of 3 images only!');
            return false;
        }
        return true;
    }
</script>

        <a href="index.php">📚 Back to Dashboard</a>
    </div>
</body>
</html>
