<?php
include '../includes/config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = sanitize($_POST['email']);
    $new_password = password_hash('123456', PASSWORD_DEFAULT); // Default reset password

    $query = "UPDATE users SET password = '$new_password' WHERE email = '$email'";
    
    if (mysqli_query($conn, $query)) {
        echo 'Password reset successfully. Default password: 123456';
    } else {
        echo 'Error: ' . mysqli_error($conn);
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="../css/styles.css">
    <title>Forgot Password</title>
</head>
<body>
    <div class="form-container">
        <h2>Forgot Password</h2>
        <form method="POST">
            <input type="email" name="email" placeholder="Enter Email" required>
            <button type="submit">Reset Password</button>
        </form>
        <p><a href="login.php">Back to Login</a></p>
    </div>
</body>
</html>
