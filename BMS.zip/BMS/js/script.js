// Like Button
function likeBook(bookId) {
    alert('❤️ Liked book with ID: ' + bookId);
    // You can send an AJAX request to increment likes here
}

// Buy Button
function buyBook(bookId) {
    alert('🛒 Book added to cart! ID: ' + bookId);
}



function likeBook(bookId) {
    alert('❤️ You liked book with ID: ' + bookId);
    // Add AJAX to update like count in the database
}

function buyBook(bookId) {
    alert('🛒 You bought book with ID: ' + bookId);
    // Add functionality to proceed with buying
}

function addToCart(bookId) {
    alert('🛍️ Book added to cart with ID: ' + bookId);
    // Add functionality to add the book to the cart
}
