<?php
// Database configuration
$host = 'localhost';
$db_name = 'book_management';
$username = 'root';
$password = 'alisaif11016@gmail.com@Saif2004';
$port = 3307;

// Create connection
$conn = mysqli_connect($host, $username, $password, $db_name, $port);

// Check connection
if (!$conn) {
    die('Connection failed: ' . mysqli_connect_error());
}
?>
